/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan;

/* USER CODE BEGIN PV */

										CAN_RxHeaderTypeDef rx_header;
										uint8_t rx_data[8];
										volatile uint32_t rx_count = 0;

								CAN_TxHeaderTypeDef tx_header;
								uint8_t tx_data[8] = {0};
								uint32_t tx_mailbox;

						volatile uint16_t motor_encoder = 0;  
						volatile uint32_t feedback_tick = 0;  
						volatile uint8_t feedback_received = 0;

						float motor_angle_deg = 0.0f;         
					      
						float target_angle_deg = 90.0f;   
						

						float kp = 40.0f;
						float ki = 0.0f;
						float kd = 2.0f;

						float pid_integral = 0.0f;
						float last_error = 0.0f;
								
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_CAN_Init(void);
/* USER CODE BEGIN PFP */

float Angle_PID(float error, float dt);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_CAN_Init();
  /* USER CODE BEGIN 2 */
	
										CAN_FilterTypeDef filter = {0};
										
										filter.FilterBank = 0;
										filter.FilterMode = CAN_FILTERMODE_IDMASK;
										filter.FilterScale = CAN_FILTERSCALE_32BIT;
										filter.FilterFIFOAssignment = CAN_RX_FIFO0;
										filter.FilterActivation = ENABLE;
										
										HAL_CAN_ConfigFilter(&hcan, &filter);
	                  HAL_CAN_Start(&hcan);
										
										HAL_CAN_ActivateNotification(&hcan, CAN_IT_RX_FIFO0_MSG_PENDING);
										
										
								tx_header.StdId = 0x1FF;
								tx_header.IDE = CAN_ID_STD;
								tx_header.RTR = CAN_RTR_DATA;
								tx_header.DLC = 8;
										
								tx_data[0] = 0x03;
								tx_data[1] = 0xE8;
										
										
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
 while (1)
{
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    static uint32_t previous_tick = 0;
    static uint8_t pid_ready = 0;

    uint16_t encoder;
    uint32_t rx_tick;
    uint32_t now;
    uint8_t received;

    float dt;
    float error;
    int16_t output = 0;

  
    __disable_irq();
    encoder = motor_encoder;
    rx_tick = feedback_tick;
    received = feedback_received;
    __enable_irq();

   
    now = HAL_GetTick();
    dt = (float)(now - previous_tick) / 1000.0f;
    previous_tick = now;

    if (received && (now - rx_tick <= 100U))
    {
        motor_angle_deg = (float)encoder * 360.0f / 8192.0f;

       
       error = target_angle_deg - motor_angle_deg;

   
        if (pid_ready == 0)
        {
            last_error = error;
            pid_integral = 0.0f;
            dt = 0.02f;
            pid_ready = 1;
        }

        output = (int16_t)Angle_PID(error, dt);
    }
    else
    {
     
        pid_integral = 0.0f;
        last_error = 0.0f;
        pid_ready = 0;
    }

    
    tx_data[0] = (uint8_t)((uint16_t)output >> 8);
    tx_data[1] = (uint8_t)output;

    HAL_CAN_AddTxMessage(&hcan, &tx_header,
                         tx_data, &tx_mailbox);

    HAL_Delay(20);
}
/* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CAN Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN_Init(void)
{

  /* USER CODE BEGIN CAN_Init 0 */

  /* USER CODE END CAN_Init 0 */

  /* USER CODE BEGIN CAN_Init 1 */

  /* USER CODE END CAN_Init 1 */
  hcan.Instance = CAN1;
  hcan.Init.Prescaler = 2;
  hcan.Init.Mode = CAN_MODE_NORMAL;
  hcan.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan.Init.TimeSeg1 = CAN_BS1_15TQ;
  hcan.Init.TimeSeg2 = CAN_BS2_2TQ;
  hcan.Init.TimeTriggeredMode = DISABLE;
  hcan.Init.AutoBusOff = DISABLE;
  hcan.Init.AutoWakeUp = DISABLE;
  hcan.Init.AutoRetransmission = DISABLE;
  hcan.Init.ReceiveFifoLocked = DISABLE;
  hcan.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN_Init 2 */

  /* USER CODE END CAN_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *can)
{
    uint16_t encoder;

    if (can != &hcan)
        return;

    if (HAL_CAN_GetRxMessage(can, CAN_RX_FIFO0,
                            &rx_header, rx_data) != HAL_OK)
        return;

    if (rx_header.IDE != CAN_ID_STD ||
        rx_header.StdId != 0x205 ||
        rx_header.RTR != CAN_RTR_DATA ||
        rx_header.DLC != 8)
        return;

    encoder = ((uint16_t)rx_data[0] << 8) | rx_data[1];

    if (encoder >= 8192)
        return;

    motor_encoder = encoder;
    feedback_tick = HAL_GetTick();
    feedback_received = 1;
    rx_count++;
}

float Angle_PID(float error, float dt)
{
    float error_change;
    float output;

    if (dt <= 0.0f)
        return 0.0f;

    
    while (error > 180.0f)
        error -= 360.0f;

    while (error < -180.0f)
        error += 360.0f;

    error_change = error - last_error;

    
    while (error_change > 180.0f)
        error_change -= 360.0f;

    while (error_change < -180.0f)
        error_change += 360.0f;

    
    pid_integral += ki * error * dt;

    if (pid_integral > 2000.0f)
        pid_integral = 2000.0f;

    if (pid_integral < -2000.0f)
        pid_integral = -2000.0f;

    
    output = kp * error + pid_integral
             + kd * error_change / dt;

    last_error = error;

    
    if (output > 5000.0f)
        output = 5000.0f;

    if (output < -5000.0f)
        output = -5000.0f;

    return output;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
