#include "rgb.h"


void RGB_Red(void)
{
  
    HAL_GPIO_WritePin(GPIOB,
                      GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_5,
                      GPIO_PIN_SET);

    
    HAL_GPIO_WritePin(GPIOB,
                      GPIO_PIN_5,
                      GPIO_PIN_RESET);
}


void RGB_Green(void)
{
    HAL_GPIO_WritePin(GPIOB,
                      GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_5,
                      GPIO_PIN_SET);

    
    HAL_GPIO_WritePin(GPIOB,
                      GPIO_PIN_0,
                      GPIO_PIN_RESET);
}


void RGB_Blue(void)
{
    HAL_GPIO_WritePin(GPIOB,
                      GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_5,
                      GPIO_PIN_SET);

   
    HAL_GPIO_WritePin(GPIOB,
                      GPIO_PIN_1,
                      GPIO_PIN_RESET);
}