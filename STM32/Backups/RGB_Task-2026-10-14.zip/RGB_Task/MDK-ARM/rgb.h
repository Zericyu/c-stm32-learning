#ifndef __RGB_H
#define __RGB_H

#include "main.h"

void RGB_Red(void);
void RGB_Green(void);
void RGB_Blue(void);

#endif